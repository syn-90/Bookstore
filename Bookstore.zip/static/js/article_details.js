function send_comment(article_id){
                   let text = $("#text_content")
                        $.get('/articels/send_comment/',{
                        'article_id' : article_id,
                        'text':text.val()
                    }).then(res =>{
                        if(res.status ==='success'){
                            alert('کامنت شما ثبت شد')
                        }else if (res.status ==='field'){
                             alert('مشکلی پیش امده لطفا دوباره تلاش کنید')
                        }
                    })
                        ;}
