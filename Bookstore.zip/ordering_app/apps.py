from django.apps import AppConfig


class OrderingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ordering_app'
